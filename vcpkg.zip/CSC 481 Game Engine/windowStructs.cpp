#pragma once
#include "windowStructs.hpp"

App* app = new App(); //defining what the app is