#pragma once
#include <SDL.h>

typedef struct {
	int w, h; // Width, height
	float posX, posY; // x and y coordinates
	float velX, velY; // Velocity
	float accX, accY; // Acceleration; developers should add their gravity value to accY if object is affected by gravity
	bool hasGravity;
	SDL_Color entityColor;
} Entity;

// Declare player entity as external variable
extern Entity player;

void updateEntity(Entity& entity);
