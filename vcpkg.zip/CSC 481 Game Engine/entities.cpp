#pragma once
#include "entities.hpp"
#include <stdio.h>

//Entity player = { 300, 300, 100, 100, 0, 0, {0, 255, 0, 255} }; // Green controllable shape

void updateEntity(Entity& entity)
{
	// Update the position of the given entity
	entity.posX += entity.velX;
	entity.posY += entity.velY;

	// Update the velocity of the given entity
	entity.velX += entity.accX;
	entity.velY += entity.accY;
}

