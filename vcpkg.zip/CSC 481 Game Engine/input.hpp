#pragma once 
#include <SDL.h>

int checkInput(SDL_Scancode key);
