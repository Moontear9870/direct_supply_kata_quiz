#pragma once
#include "physics.hpp"

float baseGravity = 0.5f; // Default gravity value, can be configured later

bool hasCollision(Entity& entity1, Entity& entity2) 
{
	const SDL_Rect rect1 = { entity1.posX, entity1.posY, entity1.w, entity1.h };
	const SDL_Rect rect2 = { entity2.posX, entity2.posY, entity2.w, entity2.h };
	return SDL_HasIntersection(&rect1, &rect2);
}

bool hasCollision(SDL_Rect *rect1, SDL_Rect *rect2)
{
	return SDL_HasIntersection(rect1, rect2);
}

float checkCollideBelow(Entity& entity1, Entity& entity2)
{
	if (hasCollision(entity1, entity2)) {
		float entity1Upper = entity1.posY;
		float entity1Lower = entity1.posY + entity1.h;
		float entity2Upper = entity2.posY;
		float entity2Lower = entity2.posY + entity2.h;
		if (entity1Lower > entity2Upper && entity1Upper < entity2Upper) {
			return entity1Lower - entity2Upper;
		}
	}
	return -1;
}

float checkCollideAbove(Entity& entity1, Entity& entity2)
{
	if (hasCollision(entity1, entity2)) {
		float entity1Upper = entity1.posY;
		float entity1Lower = entity1.posY + entity1.h;
		float entity2Upper = entity2.posY;
		float entity2Lower = entity2.posY + entity2.h;
		if (entity1Upper < entity2Lower && entity1Lower > entity2Lower) {
			return entity2Lower - entity1Upper;
		}
	}
	return -1;
}

float checkCollideRight(Entity& entity1, Entity& entity2)
{
	if (hasCollision(entity1, entity2)) {
		float entity1Left = entity1.posX;
		float entity1Right = entity1.posX + entity1.w;
		float entity2Left = entity2.posX;
		float entity2Right = entity2.posX + entity2.w;
		if (entity1Right > entity2Left && entity1Left < entity2Left) {
			return entity1Right - entity2Left;
		}
	}
	return -1;
}

float checkCollideLeft(Entity& entity1, Entity& entity2)
{
	if (hasCollision(entity1, entity2)) {
		float entity1Left = entity1.posX;
		float entity1Right = entity1.posX + entity1.w;
		float entity2Left = entity2.posX;
		float entity2Right = entity2.posX + entity2.w;
		if (entity1Left < entity2Right && entity1Right > entity2Right) {
			return entity2Right - entity1Left;
		}
	}
	return -1;
}

//void applyGravity(Entity& entity)
//{
//	if (entity.hasGravity) {
//		entity.accY = baseGravity;
//	}
//}
