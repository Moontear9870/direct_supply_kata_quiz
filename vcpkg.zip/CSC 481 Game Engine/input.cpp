#pragma once
#include "input.hpp"
#include "entities.hpp"

int checkInput(SDL_Scancode key)
{
	SDL_PumpEvents();
	int numKeys;
	const Uint8 * _cdecl keys = SDL_GetKeyboardState(&numKeys);
	return keys[key];
}
