#pragma once
#include "entities.hpp"

extern float baseGravity;

//void applyGravity(Entity& entity);
bool hasCollision(Entity& entity1, Entity& entity2);

bool hasCollision(SDL_Rect * rect1, SDL_Rect * rect2);

/**
 * Returns how much entity1's lower edge overlaps with entity2's upper edge.
 */
float checkCollideBelow(Entity& entity1, Entity& entity2);

float checkCollideAbove(Entity& entity1, Entity& entity2);

float checkCollideRight(Entity& entity1, Entity& entity2);

float checkCollideLeft(Entity& entity1, Entity& entity2);
