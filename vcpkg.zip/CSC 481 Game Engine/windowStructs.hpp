/**
 * @file windowStructs.hpp
 * @author Zoya Bawangaonwala
 *
 * TODO: add file desc that cites where we got the code from; also comment struct
 */

#pragma once
#include <SDL.h>

typedef struct {
	SDL_Renderer* renderer;
	SDL_Window* window;
} App;
