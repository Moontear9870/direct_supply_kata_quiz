#pragma once
#include "main.hpp"
#include "windowDefs.hpp"
#include <memory>

int main(int argc, char* args[])
{
	initSDL();
	Entity player = { 20, 35, 20, 265, 0, 0, 0, .5, true, {84, 143, 31, 255} };
	Entity platform = { 1000, 20, 0, 300, 0, 0, 0, 0, false, {89, 58, 18, 255} };
	Entity wall = { 20, 17, 300, 283, 0, 0, 0, 0, false, {94, 94, 94, 255} };
	Entity enemy = { 20, 20, 20, 200, 5, 0, 0, 0, false, {150, 32, 32, 255} };

	//applyGravity(player);

	while (true)
	{
		if (SDL_HasEvent(SDL_QUIT)) {
			exit(0);
		}

		prepareScene(160, 216, 255, 255);

		if (checkInput(SDL_SCANCODE_W)) {
			if (player.velY > -10) {
				player.velY -= 1;
			}
		}
		if (checkInput(SDL_SCANCODE_A)) {
			if (player.velX > -10) {
				player.velX -= 1;
			}
		}
		if (checkInput(SDL_SCANCODE_S)) {
			if (player.velY < 10) {
				player.velY += 1;
			}
		}
		if (checkInput(SDL_SCANCODE_D)) {
			if (player.velX < 10) {
				player.velX += 1;
			}
		}

		updateEntity(player);
		updateEntity(platform);
		updateEntity(wall);
		updateEntity(enemy);

		if (enemy.posX + enemy.velX > SCREEN_WIDTH - 40 || enemy.posX + enemy.velX < 20) {
			enemy.velX *= -1;
		}

		// If player is moving right, check right collisions
		if (player.velX > 0) {
			float playerPlatformCollisionRight = checkCollideRight(player, platform);
			if (playerPlatformCollisionRight != -1) {
				player.posX = platform.posX - player.w;
				if (player.velX > 0) {
					player.velX = 0;
				}
			}

			float playerWallCollisionRight = checkCollideRight(player, wall);
			if (playerWallCollisionRight != -1) {
				player.posX = wall.posX - player.w;
				if (player.velX > 0) {
					player.velX = 0;
				}
			}
		}

		// If player is moving left, check left collisions
		if (player.velX < 0) {
			float playerPlatformCollisionLeft = checkCollideLeft(player, platform);
			if (playerPlatformCollisionLeft != -1) {
				player.posX = platform.posX + platform.w;
				if (player.velX < 0) {
					player.velX = 0;
				}
			}

			float playerWallCollisionLeft = checkCollideLeft(player, wall);
			if (playerWallCollisionLeft != -1) {
				player.posX = wall.posX + wall.w;
				if (player.velX < 0) {
					player.velX = 0;
				}
			}
		}

		// If player is moving down, check below collisions
		if (player.velY > 0) {
			float playerPlatformCollisionBelow = checkCollideBelow(player, platform);
			if (playerPlatformCollisionBelow != -1) {
				player.posY = platform.posY - player.h;
				if (player.velY > 0) {
					player.velY = 0;
				}
			}

			float playerWallCollisionBelow = checkCollideBelow(player, wall);
			if (playerWallCollisionBelow != -1) {
				player.posY = wall.posY - player.h;
				if (player.velY > 0) {
					player.velY = 0;
				}
			}
		}

		// If player is moving up, check up collisions
		if (player.velY < 0) {
			float playerPlatformCollisionAbove = checkCollideAbove(player, platform);
			if (playerPlatformCollisionAbove != -1) {
				player.posY = platform.posY + platform.h;
				if (player.velY < 0) {
					player.velY = 0;
				}
			}

			float playerWallCollisionAbove = checkCollideAbove(player, wall);
			if (playerWallCollisionAbove != -1) {
				player.posY = wall.posY + wall.h;
				if (player.velY < 0) {
					player.velY = 0;
				}
			}
		}


		drawEntity(player);
		drawEntity(platform);
		drawEntity(wall);
		drawEntity(enemy);
		presentScene();
		SDL_Delay(16);
	}

	return 0;
}
