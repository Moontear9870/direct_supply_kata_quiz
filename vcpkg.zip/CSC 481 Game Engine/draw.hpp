#pragma once
#include "windowStructs.hpp"
#include "entities.hpp"
#include <SDL.h>

extern App* app;

void prepareScene(int r, int g, int b, int a);

void presentScene(void);

void drawEntity(Entity &entity);
