#pragma once
#include "windowStructs.hpp"
#include "init.hpp"
#include "draw.hpp"
#include "input.hpp"
#include "entities.hpp"
#include "physics.hpp"
#include <memory>

extern App* app;

int main(int argc, char* argv[]);
