#pragma once
#include "windowStructs.hpp"
#include <SDL.h>
#include <iostream>

//SDL window
extern App* app;

//initialize SDL rendering window
void initSDL(void);
