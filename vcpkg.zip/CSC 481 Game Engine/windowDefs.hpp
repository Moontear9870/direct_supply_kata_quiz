/**
 * @file windowDefs.hpp
 * @author Zoya Bawangaonwala
 * 
 * TODO: add file desc that cites where we got the code from; also comment struct
 */

#pragma once
#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720