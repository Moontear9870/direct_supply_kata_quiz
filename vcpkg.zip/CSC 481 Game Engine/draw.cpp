#pragma once
#include "draw.hpp"

void drawEntity(Entity &entity)
{
	SDL_Rect rect = { entity.posX, entity.posY, entity.w, entity.h };
	SDL_SetRenderDrawColor(app->renderer, entity.entityColor.r, entity.entityColor.g, entity.entityColor.b, entity.entityColor.a);
	SDL_RenderFillRect(app->renderer, &rect);
}

void prepareScene(int r, int g, int b, int a)
{
	// Original color values: (96, 128, 255, 255)
	SDL_SetRenderDrawColor(app->renderer, r, g, b, a);

	SDL_RenderClear(app->renderer);

}

void presentScene(void)
{
	SDL_RenderPresent(app->renderer);
}